# AI Content Studio

Independent, mobile-friendly content writing toolkit. Includes captions, product descriptions, hashtag suggestions, marketing emails, and browser-local saved drafts.

## Local preview
Open `index.html` in a browser, or run `python -m http.server 8000` and visit http://localhost:8000.

## Deploy on Vercel
Create a **new** GitHub repository (not TrendyLife GO), add the files at the repository root, then import the repository into Vercel. Framework preset: Other. No build command. Output directory: `.` (project root). The app is static and requires no API keys.

## Important limitations
This version uses deterministic writing templates, not a live AI model. Do not advertise AI model generation as operational until an actual provider is integrated. Saved drafts live in the visitor's localStorage and do not sync across devices. No accounts, billing, subscriptions, analytics, or backend are included.

## Ownership / resale
Keep repository, Vercel project, domain, third-party credentials and licensing separate from other products. Verify transferability and any marketplace requirements before listing. No revenue or user numbers should be claimed without records.
